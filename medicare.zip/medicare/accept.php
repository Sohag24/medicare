<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Redirecting . . .</title>
</head>

<body>


<?php
    
    
    
    
        
        session_start();
        
        //echo $_SESSION['h']; 
        $li=$_SESSION['l'];
    
        $hi=$_POST['hi'];
        
       mysql_connect("localhost","root","");
       mysql_select_db("medicare");
        
      $q=mysql_query("Select *from patients where healthcare_id='$hi'");

while($row=mysql_fetch_array($q))
{
    $sd=$row['doctor_ln'];
}

    if($sd!="None")
        
    {
        echo "<script type=\"text/javascript\">

          alert(\"Sorry Doctor Already Assigned\");
              
         </script>";
        
            echo "<script language=\"Javascript\">document.location.href='prequest.php' ;</script>";
    }
    else
    {
     mysql_query("update patients set doctor_ln='$li' where healthcare_id='$hi'");
    
      mysql_query("update request set status='accepted' where healthcare_id='$hi'");
    
         
    
    echo "<script type=\"text/javascript\">

          alert(\"Request Accepted\");
              
         </script>";
        
            echo "<script language=\"Javascript\">document.location.href='dhome.php' ;</script>";
    
    }
    
?>
   

</body>


</html>

