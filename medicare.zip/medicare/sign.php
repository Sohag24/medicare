<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>

<body>
    <center><img src="img/back.png"></center>


<?php
mysql_connect("localhost","root","");
mysql_select_db("medicare");

$count=0;

$f=$_POST["fn"];
$l=$_POST["ln"];
$a=$_POST["ag"];
$d=$_POST["ad"];
$b=$_POST["bl"];
$h=$_POST["hi"];
$sl=strlen($h);
$p=$_POST["pa"];
$dr='None';
$pic="img/back.png";
    
    
    
    $q=mysql_query("Select *from patients");

while($row=mysql_fetch_array($q))
{

 
  
  if($h==$row["healthcare_id"])
  {
     $count=1;
  }
  

}



if($sl<=3)
  {
	   echo "<script type=\"text/javascript\">

          alert(\"Sorry Healthcare id Length must be at least 4\");
              
         </script>";
        
        
        echo "<script language=\"Javascript\">document.location.href='pindex.html' ;</script>";
  }
  else
  {
    
    
	if($count==1)
    {
         echo "<script type=\"text/javascript\">

          alert(\"Sorry Healthcare Id already Exist\");
              
         </script>";
        
        
        echo "<script language=\"Javascript\">document.location.href='pindex.html' ;</script>";
        
    }
    else
    {
        
        mysql_query("insert into patients values('$f','$l','$a','$d','$b','$h','$p','$dr','$pic')");
        
            
    }




  }
  





?>
    
    <br>

    <center><h1>Welcome To Medicare Center</h1><br>
    <h3>Your Sign up process is Successfuly Completed</h3></center>
    
    <br>
    <center><a href="pindex.html" style="text-decoration:none;">Log In to Continue</a></center>


    
   
</body>
</html>
