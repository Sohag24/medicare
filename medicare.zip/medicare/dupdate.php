<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Update</title>
</head>

<body>
   

<?php
    
 session_start();   
    
$li=$_SESSION['l'];   
    
mysql_connect("localhost","root","");
mysql_select_db("medicare");



$f=$_POST["fn"];
$l=$_POST["la"];
$e=$_POST["em"];
$d=$_POST["ad"];
$j=$_POST["jb"];
$ex=$_POST["ex"];

$p=$_POST["pa"];

$pic= $_FILES["fileToUpload"]["name"];  
     
      
    if($pic!=null)
    {
       
        
//pic..........................................
        
         $target_dir = "";
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 1;
$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);

if ($uploadOk == 0) {
    echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
        echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
}

        
//..........................................
        
        
        mysql_query("update doctors set fname='$f', lname='$l', email='$e', adress='$d', job='$j', ex='$ex', password='$p', profile_pic='$pic' where licence='$li' ");
       
    }
    else
    {
    
      mysql_query("update doctors set fname='$f', lname='$l', email='$e', adress='$d', job='$j', ex='$ex', password='$p' where licence='$li' ");
     
    }
    
  
        


    
   
         echo "<script type=\"text/javascript\">

          alert(\"Information Successfully Updated\");
              
         </script>";
        
        
        echo "<script language=\"Javascript\">document.location.href='dprofile.php' ;</script>";
        
   
        
     
            
   





  





?>
    
    <br>

    <center><h1>Welcome To Medicare Center</h1><br>
    <h3>Your Sign up process is Successfuly Completed</h3></center>
    
    <br>
    <center><a href="index.html" style="text-decoration:none;">Log In to Continue</a></center>


    
   
</body>
</html>
