<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Redirecting . . .</title>
</head>

<body>


<?php

   
    session_start();
    
$_SESSION['h']=$_POST["hi"];
    
    

$h=$_POST["hi"];
$p=$_POST["pa"];
$count=0;

mysql_connect("localhost","root","");
mysql_select_db("medicare");



$q=mysql_query("Select *from patients");

while($row=mysql_fetch_array($q))
{

 
  
  if($h==$row["healthcare_id"] && $p==$row["password"])
  {
     $count=1;
  }
  

}
    
    if($count==1)
    {
        echo "<br>";
        echo " <h3>Welcome You are Successfuly Logged In . . .</h3>";
      echo "<hr>";
        
         echo "<script language=\"Javascript\">document.location.href='home.php' ;</script>";
        
    }
    else
    {
         echo "<script type=\"text/javascript\">

          alert(\"Wrong Healthcare Id Or Password\");
              
         </script>";
        
            echo "<script language=\"Javascript\">document.location.href='pindex.html' ;</script>";
    }


?>



</body>


</html>

