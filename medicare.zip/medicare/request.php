<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Redirecting . . .</title>
</head>

<body>


<?php
    
    
    
    session_start();
        
        //echo $_SESSION['h']; 
        $hid=$_SESSION['h'];
        $li=$_POST['li'];
        
       mysql_connect("localhost","root","");
       mysql_select_db("medicare");
        
     
     mysql_query("insert into request values('$hid','$li','sent')");
    
    
    echo "<script type=\"text/javascript\">

          alert(\"Request Sent\");
              
         </script>";
        
            echo "<script language=\"Javascript\">document.location.href='home.php' ;</script>";
    
    
    
?>
   

</body>


</html>

