<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    
    <link rel="stylesheet" type="text/css" href="css/mystyle.css">
    
<title>Home</title>
</head>

<body>

    
    
    <div id="container">
        
        <div id="head">
            
            <form style="float:left;"  action="doctor_search.php" method="post">
                
                <input type="text" placeholder="Search for Doctors" style="height:30px; width:350px; border-radius:5px; font-size:16px; padding-left:15px; color:cadetblue;" name="name">
                &nbsp;
                <input type="submit" value="Search" style="height:35px; width:80px; border-radius:5px; font-size:16px;">
                
            </form>
                
         
             <a href="home.php">Home</a>
            
             <a href="profile.php">Profile</a>
            
             <a href="updateinfo.php">Update Info</a>
        
        </div>
        
        
        
       
        
        <?php
       
        
        session_start();
        
        //echo $_SESSION['h']; 
        $hid=$_SESSION['h'];
        
        
       mysql_connect("localhost","root","");
       mysql_select_db("medicare");
        
        
        $q=mysql_query("Select *from patients where healthcare_id='$hid'");

while($row=mysql_fetch_array($q))
{

  
    $name=$row['fname']." ".$row['lname'];
    $addr=$row['adress'];
    $pic=$row['profile_pic'];
  
  

}


        
        
        
        
        ?>
        
        
        
        
        
       
        <div id="body">
            
           <div id="body1"> 
               
               <div id="body2">
                   
                   <img src=<?php echo $pic; ?> height="160px" width="160px" style="border:solid; border-color:cyan;">
               
               </div>
               
               <div id="body2">
                   
                   <h1><?php echo $name; ?></h1>
                   <h3><?php echo $addr; ?></h3>
               
               </div>
               
               
            
           </div>
            
          
          
            
             <form action="post.php" method="post" enctype="multipart/form-data">
            
                 
                   <input type="file" name="fileToUpload" id="fileToUpload">
                 
                 <input type="text" placeholder="Write your status here" style="height:45px; width:550px;  font-size:16px; padding-left:15px; color:cadetblue;" name="post" >
                
                
                 
                 <input type="submit" value="Post" style="height:50px; width:100px; border-radius:5px; font-size:16px;">
                <br>
                 
            </form>
            
            <h2>Recent Reports</h2>
            
        <hr style="color:white;">  
            
            
            
           <?php
            
            
              $q=mysql_query("Select *from reports where healthcare_id='$hid' order by id DESC");

while($row=mysql_fetch_array($q))
{

   
    $p=$row['post'];
    $pd=$row['pdate'];
    $li=$row['licence'];
    $r=$row['report'];
    $rf=$row['rfile'];
    $rd=$row['rdate'];
    $s=$row['status'];
    
    if($s=='Show')
    {
    echo "<img src='img/back1.png' height='50px' width='200px' align='middle'>";
    echo "<p style='color:green;'>Doctors id : ".$li."&nbsp&nbsp&nbsp Date : ".$rd."<br><br></p>";
    
    echo "<h2 style='color:burlywood;'> &nbsp&nbsp".$r."<br><br></h2>";
        
        echo "<a href='$rf' style='text-decoration:none; color:green;'>$rf</a><br><br>";
    
    echo "<hr style='color:white; '>";  
    
    
    }

  

}
         
            
            
            

            
            
            ?>
            
            
            
        
            
        </div>
        
        <div id="sidebar">
            
            
            <img src="img/back2.jpg" width="200px">
       
           <br><br>
            
        <a href="doctor_list.php">Doctors List</a>
           
            <br><br>
            
            
        <a href="mypost.php">Your Posts</a>
           
         <br><br>
            
            
        <a href="home.php">Your Reports</a>
           
        <br><br>
            
        <a href="sign_out.php">Sign Out</a>
           
        <br><br>
            
            
            <img src="img/back3.jpg">
        
        </div>
        
      
    </div>
    
    
</body>
    
</html>