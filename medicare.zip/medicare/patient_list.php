<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    
    <link rel="stylesheet" type="text/css" href="css/mystyle.css">
    
<title>Home</title>
</head>

<body>

    
    
    <div id="container">
        
        <div id="head">
            
            <form style="float:left"; action="patient_search.php" method="post" ">
                
                <input type="text" placeholder="Search for Patient" style="height:30px; width:350px; border-radius:5px; font-size:16px; padding-left:15px; color:cadetblue;" name="name">
                &nbsp;
                <input type="submit" value="Search" style="height:35px; width:80px; border-radius:5px; font-size:16px;">
                
            </form>
                
         
             <a href="dhome.php">Home</a>
            
             <a href="dprofile.php">Profile</a>
            
              <a href="dupdateinfo.php">Update Info</a>
        
        </div>
        
        
        
       
        
        <?php
       
        
        session_start();
        
        //echo $_SESSION['h']; 
        $li=$_SESSION['l'];
        
        
       mysql_connect("localhost","root","");
       mysql_select_db("medicare");
        
        
        $q=mysql_query("Select *from doctors where licence='$li'");

while($row=mysql_fetch_array($q))
{

  
    $name=$row['fname'];
    $addr=$row['adress'];
    $pic=$row['profile_pic'];
  
  

}


        
        
        
        
        ?>
        
        
        
        
        
       
        <div id="body">
            
           <div id="body1"> 
               
               <div id="body2">
                   
                   <img src=<?php echo $pic; ?> height="160px" width="160px" style="border:solid; border-color:cyan;">
               
               </div>
               
               <div id="body2">
                   
                   <h1><?php echo $name; ?></h1>
                   <h3><?php echo $addr; ?></h3>
               
               </div>
               
               
            
           </div>
            
          
          
            
             
            
            <h2>Patients </h2>
            
            <hr style="color:aliceblue;">
            
            
            
               <?php
            
            
           
        
        
     //   $hid=$_SESSION['h'];
        
        
       
            
mysql_connect("localhost","root","");
mysql_select_db("medicare");
            
            
             $q=mysql_query("Select *from patients where doctor_ln='$li'");

while($row=mysql_fetch_array($q))
{
   
$f=$row["fname"];
$l=$row["lname"];
$ag=$row["age"];
$a=$row["adress"];
$b=$row["blood"];
$p=$row["profile_pic"];
$hi=$row["healthcare_id"];
    
    echo "<img src='$p' height='100px' width='100px'>";
    echo "<pre><h2>".$f." ".$l."</h2></pre>";
   // echo "<br><br>Age        : ".$a;
  //  echo "<br><br>Adress     : ".$a;
   // echo "<br><br>Blood      : ".$b;
    //echo "<br><br>Health id  : ".$hi."<h2></pre>";
	
	 echo "<form action='aboutp.php' method='post'>
    <input type='hidden' value='$hi' name='hid'>
    <input style='height:35px; width:250px; color:white; font-size:16px; letter-spacing:2px; background-color:cadetblue; float:left;' type='submit' value='Show Profile'></form><br>";
    
    echo "<br><hr style='color:aliceblue;'>";
    
    
}
            
            
            ?>
            
            
            
            
            
            
          
            
         
            
        
            
        </div>
        
        <div id="sidebar">
            
            
            <img src="img/back2.jpg" width="200px">
       
           <br><br>
            
        <a href="patient_list.php">Patients List</a>
           
            <br><br>
            
        
            
        <a href="prequest.php">Patients Request</a>
           
         <br><br>
            
            
        <a href="myreports.php">Your Reports</a>
           
        <br><br>
            
        <a href="sign_out.php">Sign Out</a>
           
        <br><br>
            
              <img src="img/back3.jpg">
            
        
        </div>
        
      
    </div>
    
    
</body>
    
</html>