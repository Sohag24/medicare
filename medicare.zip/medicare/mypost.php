<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    
    <link rel="stylesheet" type="text/css" href="css/mystyle.css">
    
<title>Home</title>
</head>

<body>

    
    
    <div id="container">
        
        <div id="head">
            
            <form style="float:left;"  action="doctor_search.php" method="post">
                
                <input type="text" placeholder="Search for Doctors" style="height:30px; width:350px; border-radius:5px; font-size:16px; padding-left:15px; color:cadetblue;" name="name">
                &nbsp;
                <input type="submit" value="Search" style="height:35px; width:80px; border-radius:5px; font-size:16px;">
                
            </form>
                
         
             <a href="home.php">Home</a>
            
             <a href="profile.php">Profile</a>
            
             <a href="updateinfo.php">Update Info</a>
        
        </div>
        
        
        
       
        
        <?php
       
        
        session_start();
        
        //echo $_SESSION['h']; 
        $hid=$_SESSION['h'];
        
        
       mysql_connect("localhost","root","");
       mysql_select_db("medicare");
        
        
        $q=mysql_query("Select *from patients where healthcare_id='$hid'");

while($row=mysql_fetch_array($q))
{

  
    $name=$row['fname']." ".$row['lname'];
    $addr=$row['adress'];
    $pic=$row['profile_pic'];
  
  

}


        
        
        
        
        ?>
        
        
        
        
        
       
        <div id="body">
            
           <div id="body1"> 
               
               <div id="body2">
                   
                   <img src=<?php echo $pic; ?> height="160px" width="160px" style="border:solid; border-color:cyan;">
               
               </div>
               
               <div id="body2">
                   
                   <h1><?php echo $name; ?></h1>
                   <h3><?php echo $addr; ?></h3>
               
               </div>
               
               
            
           </div>
            
          
          
            
             
            <h2>Your Posts</h2>
            
        <hr style="color:white;">  
            
            
            
           <?php
            
            
              $q=mysql_query("Select *from reports where healthcare_id='$hid' order by id DESC");

while($row=mysql_fetch_array($q))
{

   
    $p=$row['post'];
    $pd=$row['pdate'];
   // $li=$row['licence'];
   // $r=$row['report'];
   // $rd=$row['rdate'];
   // $s=$row['status'];
    
    
    echo "<img src='img/back1.png' height='50px' width='200px' align='middle'>";
    echo "<p style='color:green;'>&nbsp&nbsp&nbsp Date : ".$pd."<br><br></p>";
    
    echo "<h2 style='color:burlywood;'> &nbsp&nbsp".$p."<br><br></h2>";
    
    echo "<hr style='color:white; '>";  
    
    
    

  

}
         
            
            
            

            
            
            ?>
            
            
            
        
            
        </div>
        
        <div id="sidebar">
            
            
            <img src="img/back2.jpg" width="200px">
       
           <br><br>
            
        <a href="doctor_list.php">Doctors List</a>
           
            <br><br>
            
            
        <a href="mypost.php">Your Posts</a>
           
         <br><br>
            
            
         <a href="home.php">Your Reports</a>
           
        <br><br>
            
        <a href="sign_out.php">Sign Out</a>
           
        <br><br>
            
              <img src="img/back3.jpg">
            
        
        </div>
        
      
    </div>
    
    
</body>
    
</html>