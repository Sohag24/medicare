<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>

<body>
    <center><img src="img/back.png"></center>


<?php

mysql_connect("localhost","root","");
mysql_select_db("medicare");




session_start();   
    
$hid=$_SESSION['h'];
    
$p=$_POST["post"];
$date=date("Y-m-d");
$pfile= $_FILES["fileToUpload"]["name"];  
    
    
    $q=mysql_query("Select *from patients where healthcare_id='$hid'");

while($row=mysql_fetch_array($q))
{
    $li=$row['doctor_ln'];
}

    
    
    
    
    
    if($pfile!=null)
    {
       
        
//pic..........................................
        
         $target_dir = "";
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 1;
$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);

if ($uploadOk == 0) {
    echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
        echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
}

        
//..........................................
        
        
        mysql_query("insert into reports values('$hid','$p','$pfile','$date','$li',' ',' ',' ',' ',' ')");
        
    }
    else
    {
       mysql_query("insert into reports values('$hid','$p',' ','$date','$li',' ',' ',' ',' ',' ')");
     
    }
    
    
    
    
        
     
        
            
  

 echo "<script language=\"Javascript\">document.location.href='home.php' ;</script>";



  





?>
    
    <br>

    <center><h1>Welcome To Medicare Center</h1><br>
    <h3>Your Sign up process is Successfuly Completed</h3></center>
    
    <br>
    <center><a href="index.html" style="text-decoration:none;">Log In to Continue</a></center>


    
   
</body>
</html>
